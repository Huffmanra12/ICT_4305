import java.util.ArrayList;
import java.util.List;

public class Customer {

    private String customerID;
    private String firstName;
    private String lastName;
    private Address address;
    private String phoneNumber;
    private List<Car> cars;

    public Customer(String customerID, String firstName, String lastName, Address address, String phoneNumber) {

        this.customerID = customerID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.cars = new ArrayList<>();

    }

    public Car register(String license, CarType type) {
        String permitID = "Permit-" + license;

        Car newCar = new Car(permitID, license, type, this.customerID);
        this.cars.add(newCar);

        return newCar;
    }

    public String getCustomerID() { return customerID; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public Address getAddress() { return address; }
    public String getPhoneNumber() { return phoneNumber; }
    public List<Car> getCars() { return cars; }

    @Override
    public String toString() {
        return "Customer ID: " + customerID + ", Customer name: " + firstName + " " + lastName + ", Address: " + address +
                ", Phone Number: " + phoneNumber;
    }
}
