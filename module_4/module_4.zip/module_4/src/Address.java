public class Address {
    private String streetAddress1 = "";
    private String streetAddress2 = "";
    private String city = "";
    private String state = "";
    private String zipCode = "";

    public Address (String streetAddress1, String streetAddress2, String city, String state, String zipCode) {
        this.streetAddress1 = streetAddress1;
        this.streetAddress2 = streetAddress2;
        this.city = city;
        this.state = state;
        this.zipCode = zipCode;
    }

    public String getStreetAddress1() { return streetAddress1; }
    public String getStreetAddress2() { return streetAddress2; }
    public String getCity() { return city; }
    public String getState() { return state; }
    public String getZipCode() { return zipCode; }

    public String getAddressInfo() {
        return streetAddress1 + (streetAddress2.isEmpty() ? "" : ", " + streetAddress2) + ", " + city + ", "
                + state + " " + zipCode;
    }

    @Override
    public String toString() {
        return getAddressInfo();
    }
}
