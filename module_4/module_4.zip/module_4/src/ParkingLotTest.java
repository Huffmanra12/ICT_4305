import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class ParkingLotTest {

    Address lotAddress = new Address("3333 Regis Blvd", "", "Denver", "CO",
            "80221");
    String addressString = lotAddress.toString();

    ParkingLot lot = new ParkingLot("Lot 1", lotAddress, 100);

    @Test
    void testSetCapacity() {

        lot.setCapacity(150);
        assertEquals(150, lot.getCapacity());
    }

    @Test
    void testGetLotAddress() {

        assertEquals(lotAddress, lot.getAddress());
    }

    @Test
    void testGetLotID() {

        assertEquals("Lot 1", lot.getLotID());
    }

    @Test
    void testGetDetails() {

        assertEquals("Parking Lot: Lot 1 Capacity: 100 Location: 3333 Regis Blvd, Denver, CO 80221", lot.toString());
    }

}
