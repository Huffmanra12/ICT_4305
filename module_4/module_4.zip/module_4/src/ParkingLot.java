public class ParkingLot {

    private String lotID = "";
    private Address address;
    private Integer capacity = 0;


    public ParkingLot(String lotID, Address address, Integer capacity) {
        this.lotID = lotID;
        this.address = address;
        this.capacity = capacity;
    }

    public String getLotID() { return  lotID; }
    public Integer getCapacity() { return capacity; }
    public Address getAddress() { return address; }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    @Override
    public String toString() {
        return "Parking Lot: " + lotID + " Capacity: " + capacity + " Location: " + address;
    }
}
