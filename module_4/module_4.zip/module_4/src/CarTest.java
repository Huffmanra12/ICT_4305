import static org.junit.jupiter.api.Assertions.assertEquals;
import java.time.LocalDate;
import org.junit.jupiter.api.Test;

public class CarTest {
    Car car = new Car("Permit-1234567", "1234567", CarType.TRUCK, "12345678");

    @Test
    void testGetPermit() {

        assertEquals("Permit-1234567", car.getPermit());
    }

    @Test
    void testGetPermitExpiration(){
        LocalDate expectedDate = LocalDate.now().plusYears(1);

        assertEquals(expectedDate, car.getPermitExpiration());
    }

    @Test
    void testGetLicense() {

        assertEquals("1234567", car.getLicense());
    }

    @Test
    void testGetType() {

        assertEquals(CarType.TRUCK, car.getType());
    }

    @Test
    void getOwnerID() {

        assertEquals("12345678", car.getOwnerID());
    }

    @Test
    void getDetails() {

        assertEquals("Car License: 1234567, Type: TRUCK, Permit: Permit-1234567", car.toString());
    }

}
