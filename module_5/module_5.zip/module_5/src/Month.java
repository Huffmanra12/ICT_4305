public class Month<T> {
    private T month;

    //constructors
    public Month() {
    }

    public Month(T month) {

        this.month = month;
    }
//getter
    public T getMonth() {
        return month;
    }
//setter
    public void setMonth(T month) {

        this.month = month;
    }
}
