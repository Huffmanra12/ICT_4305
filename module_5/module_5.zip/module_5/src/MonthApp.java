import java.util.HashMap;
import java.util.Map;

public class MonthApp {

    public static void main(String[] args) {

        // HashMap to store month index and name
        Map<Month<Integer>, Month<String>> months = new HashMap<>();

        String[] monthNames = {
                "January", "February", "March", "April", "May", "June", "July",
                "August", "September", "October", "November", "December"
        };

        // Populates HashMap
        for (int i = 0; i < 12; i++) {
            //To get the day of the month i increments
            Month<Integer> monthNumber = new Month<>(i + 1);
            //will equal the value in the positon equal to i.
            //logic starts counting at 0 meaning when i=0 the value in monthNames is January
            Month<String> monthName = new Month<>(monthNames[i]);

            //takes the value of monthNumber and monthName and adds them to the HashMap
            months.put(monthNumber, monthName);
        }
        //iterates over the HashMap printing the key:value pair
        for (Map.Entry<Month<Integer>, Month<String>> entry : months.entrySet()) {
            System.out.println(
                    entry.getKey().getMonth() + " = " + entry.getValue().getMonth()
            );
        }
    }
}
