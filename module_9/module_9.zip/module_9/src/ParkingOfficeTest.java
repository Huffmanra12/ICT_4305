import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class ParkingOfficeTest {

    Address officeAddress = new Address("2199 S University Blvd", "", "Denver", "CO", "80208");
    Address customerAddress = new Address("1020 S Blackhawk st", "Apt 2214", "Aurora", "CO", "80012");

    ParkingOffice office = new ParkingOffice("Admin Office", officeAddress);

    Customer c = office.register("123456789", "Richard", "Huffman", customerAddress, "555-555-555");
    Car car = office.register(c, "ABC123", CarType.SUV);
    Car car2 = office.register(c, "XYZ789", CarType.TRUCK);

    @Test
    void testRegisterCustomer() {
        assertEquals("Permit-ABC123", car.getPermit());
        assertEquals("ABC123", car.getLicense());
        assertEquals(CarType.SUV, car.getType());
        assertEquals("123456789", car.getOwnerID());
    }

    @Test
    void testAddCharge() {
        Money amount = new Money(1000);
        ParkingCharge charge = new ParkingCharge("Permit-ABC123", "Lot 1", Instant.now(), amount);

        Money returned = office.addCharge(charge);

        assertEquals(1000, returned.getCents());
        assertEquals("$10.00", returned.toString());
        assertSame(amount, returned);
    }

    @Test
    void testGetCustomerIds() {
        List<String> ids = office.getCustomerIds();

        assertEquals(1, ids.size());
        assertTrue(ids.contains("123456789"));
    }

    @Test
    void testGetPermitIds() {
        List<String> permitIds = office.getPermitIds();

        assertEquals(2, permitIds.size());
        assertTrue(permitIds.contains("Permit-ABC123"));
        assertTrue(permitIds.contains("Permit-XYZ789"));
    }

    @Test
    void testGetPermitIdsForCustomer() {
        List<String> permitIds = office.getPermitIds(c);

        assertEquals(2, permitIds.size());
        assertTrue(permitIds.contains("Permit-ABC123"));
        assertTrue(permitIds.contains("Permit-XYZ789"));
    }
}