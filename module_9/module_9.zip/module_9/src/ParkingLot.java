import java.time.Instant;
import java.util.Objects;

public class ParkingLot {

    private String lotID = "";
    private Address address;
    private Integer capacity = 0;

    private ParkingOffice office;

//constructor
    public ParkingLot(String lotID, Address address, Integer capacity, ParkingOffice office) {
        this.lotID = lotID;
        this.address = address;
        this.capacity = capacity;
        this.office = office;
    }

    //getters
    public String getLotID() { return  lotID; }
    public Integer getCapacity() { return capacity; }
    public Address getAddress() { return address; }

    //setter
    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    //methods
    public Money enter(String permitID) {
        Car car = office.getCarByPermit(permitID);

        if (car == null) {
            throw new IllegalArgumentException("Invalid Permit");
        }

        long baseFee = 1000;

        if (car.getType() == CarType.COMPACT) {
            baseFee = (long) (baseFee * 0.8);
        }

        Money amount = new Money(baseFee);

        ParkingCharge charge =
                new ParkingCharge(permitID, lotID, Instant.now(), amount);

        office.addCharge(charge);

        return amount;
    }


    @Override
    public String toString() {
        return "Parking Lot: " + lotID + " Capacity: " + capacity + " Location: " + address;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ParkingLot)) return false;
        ParkingLot that = (ParkingLot) o;
        return Objects.equals(lotID, that.lotID);
    }

    @Override
    public int hashCode() {
        return Objects.hash(lotID);
    }
}
