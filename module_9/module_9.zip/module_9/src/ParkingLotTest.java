import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ParkingLotTest {

    Address lotAddress = new Address("3333 Regis Blvd", "", "Denver", "CO", "80221");

    Address officeAddress = new Address("2199 S University Blvd", "", "Denver", "CO", "80208");

    Address customerAddress = new Address("1020 S Blackhawk st", "Apt 2214", "Aurora", "CO", "80012");

    ParkingOffice parkingOffice = new ParkingOffice("Admin Office", officeAddress);

    ParkingLot lot = new ParkingLot("Lot 1", lotAddress, 100, parkingOffice);

    Customer c = parkingOffice.register("123456789", "Richard", "Huffman", customerAddress, "555-555-555");
    Car car = parkingOffice.register(c, "ABC123", CarType.SUV);
    Car car2 = parkingOffice.register(c, "123ABC", CarType.COMPACT);

    @Test
    void testSetCapacity() {
        lot.setCapacity(150);
        assertEquals(150, lot.getCapacity());
    }

    @Test
    void testGetLotAddress() {
        assertEquals(lotAddress, lot.getAddress());
    }

    @Test
    void testGetLotID() {
        assertEquals("Lot 1", lot.getLotID());
    }

    @Test
    void testGetDetails() {
        assertEquals("Parking Lot: Lot 1 Capacity: 100 Location: 3333 Regis Blvd, Denver, CO 80221", lot.toString());
    }

    @Test
    void testInvalidPermit() {
        assertThrows(IllegalArgumentException.class, () -> lot.enter("123"));
    }

    @Test
    void testValidPermit() {
        String permitID = car.getPermit();
        Money amount = lot.enter(permitID);

        assertNotNull(amount);
        assertEquals(1000, amount.getCents());
        assertEquals("$10.00", amount.toString());
    }

    @Test
    void testValidPermit_Discount() {
        String permitId = car2.getPermit();
        Money amount = lot.enter(permitId);

        assertNotNull(amount);
        assertEquals(800, amount.getCents());
        assertEquals("$8.00", amount.toString());
    }

    @Test
    void testEqualsAndHashCode() {
        ParkingLot lot2 = new ParkingLot("Lot 1", lotAddress, 999, parkingOffice);
        assertEquals(lot, lot2);
        assertEquals(lot.hashCode(), lot2.hashCode());
    }
}