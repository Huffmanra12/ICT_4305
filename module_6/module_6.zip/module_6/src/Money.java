public final class Money {
    private final long cents;

    //constructors
    public Money(long cents) {
        this.cents = cents;
    }

     //getters
    public long getCents() {
        return cents;
    }

    public double getDollars() {
        return cents / 100.0;
    }

    @Override
    public String toString() {
        long abs = Math.abs(cents);
        long dollars = abs / 100;
        long rem = abs % 100;
        String sign = cents < 0 ? "-" : "";
        return String.format("%s$%d.%02d", sign, dollars, rem);
    }


}
