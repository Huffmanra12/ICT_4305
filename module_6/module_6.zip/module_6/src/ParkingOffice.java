import java.util.ArrayList;
import java.util.List;

public class ParkingOffice {
    private final String name;
    private final Address address;

    private final List<Customer> customers = new ArrayList<>();
    private final List<Car> cars = new ArrayList<>();
    private final List<ParkingLot> lots = new ArrayList<>();
    private final List<ParkingCharge> charges = new ArrayList<>();

    //constructor

    public ParkingOffice(String name, Address address) {
        this.name = name;
        this.address = address;
    }

    //methods
    public Customer register(String customerID, String firstName, String lastName, Address address, String phoneNumber) {
        Customer c = new Customer(customerID, firstName, lastName, address, phoneNumber);
        customers.add(c);
        return c;
    }

    public Car register(Customer c, String license, CarType t) {
        Car car = c.register(license, t);
        cars.add(car);
        return car;
    }

    //find customer by id
    public Customer getCustomer(String customerID) {
        for (Customer c : customers) {
            if (c.getCustomerID().equals(customerID)) return c;
        }
        return null;
    }

    //find car by permit id
    public Car getCarByPermit(String permitID) {
        for (Car car : cars) {
            if (car.getPermit().equals(permitID)) return car;
        }
        return null;
    }

    //add charge
    public Money addCharge(ParkingCharge charge) {
        charges.add(charge);
        return charge.getAmount();
    }

    public void addLot(ParkingLot lot) {
        lots.add(lot);
    }
}
