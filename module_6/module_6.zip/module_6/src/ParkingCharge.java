import java.time.Instant;

public class ParkingCharge {
    private final String permitID;
    private final String lotID;
    private final Instant incurred;
    private final Money amount;

    //constructor
    public ParkingCharge(String permitID, String lotID, Instant incurred, Money amount) {
        this.permitID = permitID;
        this.lotID = lotID;
        this.incurred = incurred;
        this.amount = amount;
    }
    //getters
    public String getPermitID() { return permitID; }
    public String getLotID() { return lotID; }
    public Instant getIncurred() { return incurred; }
    public Money getAmount() { return amount; }

    @Override
    public String toString() {
        return String.format(
                "ParkingCharge{permitId=%s, lotId=%s, incurred=%s, amount=%s}", permitID, lotID, incurred, amount);
    }
}
