import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class MoneyTest {

    Money money = new Money(467);

    @Test
    void testGetCents() {
        assertEquals(467, money.getCents());
    }

    @Test
    void testGetDollars() {
        assertEquals(4.67, money.getDollars());
    }

    @Test
    void testString() {
        assertEquals("$4.67", money.toString());
    }
}
