import org.junit.jupiter.api.Test;

import java.time.Instant;

import static org.junit.jupiter.api.Assertions.*;

public class ParkingChargeTest {

    Money amount = new Money(1500);

    ParkingCharge charge = new ParkingCharge("123456789", "Lot A", Instant.now(), amount);

    @Test
    void testGetPermitID() {

        assertEquals("123456789", charge.getPermitID());
    }

    @Test
    void testGetLotID() {

        assertEquals("Lot A", charge.getLotID());
    }

    @Test
    void testGetIncurred() {

        assertEquals(Instant.now(), charge.getIncurred());
    }


    @Test
    void testToString() {

        String result = charge.toString();

        assertTrue(result.contains("123456789"));
        assertTrue(result.contains("Lot A"));
        assertTrue(result.contains("$15.00"));
    }
}
