import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CustomerTest {
    Address addr = new Address("1020 S Blackhawk St", "Apt 2214", "Aurora", "CO", "80012");
    Customer customer = new Customer("1234567", "Richard", "Huffman", addr, "555-555-5555");

    @Test
    void testRegister() {
        customer.register("987654321", CarType.TRUCK);
        customer.register("897654321", CarType.SUV);

        List<Car> carList = customer.getCars();

        assertEquals(2, carList.size());
        assertEquals("987654321", carList.get(0).getLicense());
        assertEquals("897654321", carList.get(1).getLicense());
    }

    @Test
    void testGetCustomerID() {
        assertEquals("1234567", customer.getCustomerID());
    }

    @Test
    void testGetFirstName() {
        assertEquals("Richard", customer.getFirstName());
    }

    @Test
    void testGetLastName() {
        assertEquals("Huffman", customer.getLastName());
    }

    @Test
    void testGetAddress() {
        assertEquals(addr, customer.getAddress());
    }

    @Test
    void testGetPhoneNumber() {
        assertEquals("555-555-5555", customer.getPhoneNumber());
    }

    @Test
    void testGetDetails() {
        assertEquals("Customer ID: 1234567, Customer name: Richard Huffman, Address: 1020 S Blackhawk St, Apt 2214, Aurora, CO 80012, Phone Number: 555-555-5555", customer.toString());
    }

    @Test
    void testEqualsAndHashCode() {
        Customer customer2 = new Customer("1234567", "Monkey", "Luffy", addr, "000-000-0000");
        assertEquals(customer, customer2);
        assertEquals(customer.hashCode(), customer2.hashCode());
    }
}