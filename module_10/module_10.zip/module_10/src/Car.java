import java.time.LocalDate;
import java.util.Objects;

public class Car {
    private String permit;
    private LocalDate permitExpiration;
    private String license;
    private CarType type;
    private String ownerID;

    //constructor
    public Car(String permit, String license, CarType type, String ownerID) {
        this.permit = permit;
        this.license = license;
        this.type = type;
        this.ownerID = ownerID;
        this.permitExpiration = LocalDate.now().plusYears(1);
    }

    //getters
    public String getPermit() { return permit; }
    public LocalDate getPermitExpiration() { return permitExpiration; }
    public String getLicense() { return  license; }
    public CarType getType() { return type; }
    public String getOwnerID() { return ownerID; }

    @Override
    public String toString() {
        return "Car License: " + license + ", Type: " + type + ", Permit: " + permit;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Car)) return false;
        Car car = (Car) o;
        return Objects.equals(permit, car.permit);
    }

    @Override
    public int hashCode() {
        return Objects.hash(permit);
    }
}
