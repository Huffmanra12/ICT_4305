import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class TransactionManagerTest {
    @Test
    void testParkingAndCharges() {
        TransactionManager tm = new TransactionManager();
        Car car = new Car("N/A", "ABC", CarType.SUV, "C1");
        ParkingPermit permit = new ParkingPermit("P1", car, java.time.LocalDate.now());
        ParkingLot lot = new ParkingLot("L1", "Lot", null, new Money(1000));

        tm.park(new Date(), permit, lot);
        tm.park(new Date(), permit, lot);

        Money total = tm.getParkingCharges(permit);
        assertEquals(2000, total.getCents());
    }
}