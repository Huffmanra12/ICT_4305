import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ParkingOffice {

    private String name;
    private Address address;

    private List<Customer> customers = new ArrayList<>();
    private List<ParkingLot> lots = new ArrayList<>();

    private PermitManager permitManager = new PermitManager();
    private TransactionManager transactionManager = new TransactionManager();

    public ParkingOffice(String name, Address address) {
        this.name = name;
        this.address = address;
    }

    public void register(Customer customer) {
        if (!customers.contains(customer)) {
            customers.add(customer);
        }
    }

    public ParkingPermit register(Car car) {
        return permitManager.register(car);
    }

    public ParkingTransaction park(Instant date, ParkingPermit permit, ParkingLot lot) {
        return transactionManager.park(Date.from(date), permit, lot);
    }

    public Money getParkingCharges(ParkingPermit permit) {
        return transactionManager.getParkingCharges(permit);
    }

    public Money getParkingCharges(Customer customer) {

        long total = 0;

        for (Car car : customer.getCars()) {
            Money charges = transactionManager.getParkingCharges(car.getLicense());
            total += charges.getCents();
        }

        return new Money(total);
    }

    public void addParkingLot(ParkingLot lot) {
        lots.add(lot);
    }

    public String getParkingOfficeName() {
        return name;
    }

    public List<String> getCustomerIds() {

        List<String> ids = new ArrayList<>();

        for (Customer c : customers) {
            ids.add(c.getCustomerID());
        }

        return ids;
    }

    public List<String> getPermitIds() {

        return new ArrayList<>(permitManager.getPermits().keySet());
    }

    public List<String> getPermitIds(Customer customer) {

        List<String> ids = new ArrayList<>();

        for (Car car : customer.getCars()) {
            ids.add(car.getPermit());
        }

        return ids;
    }

    public List<Customer> getCustomers() {
        return customers;
    }

    public List<ParkingLot> getParkingLots() {
        return lots;
    }
}