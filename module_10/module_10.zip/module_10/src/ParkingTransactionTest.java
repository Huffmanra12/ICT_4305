import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class ParkingTransactionTest {
    @Test
    void testTransactionData() {
        Car car = new Car("N/A", "ABC", CarType.SUV, "C1");
        ParkingPermit permit = new ParkingPermit("P1", car, java.time.LocalDate.now());
        ParkingLot lot = new ParkingLot("L1", "Lot", null, new Money(500));
        Date now = new Date();

        ParkingTransaction tx = new ParkingTransaction(now, permit, lot, new Money(500));
        assertEquals(permit, tx.getPermit());
        assertEquals(now, tx.getTransactionDate());
    }
}