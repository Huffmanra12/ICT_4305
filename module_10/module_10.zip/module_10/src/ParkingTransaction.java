import java.util.Date;

public class ParkingTransaction {
    private final Date transactionDate;
    private final ParkingPermit permit;
    private final ParkingLot lot;
    private final Money feeCharged;

    public ParkingTransaction(Date date, ParkingPermit permit, ParkingLot lot, Money feeCharged) {
        this.transactionDate = date;
        this.permit = permit;
        this.lot = lot;
        this.feeCharged = feeCharged;
    }

    public Date getTransactionDate() { return transactionDate; }
    public ParkingPermit getPermit() { return permit; }
    public Money getFeeCharged() { return feeCharged; }
}