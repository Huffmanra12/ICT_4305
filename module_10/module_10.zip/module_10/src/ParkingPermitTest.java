import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

public class ParkingPermitTest {
    @Test
    void testPermitDates() {
        Car car = new Car("N/A", "ABC", CarType.SUV, "C1");
        LocalDate today = LocalDate.now();
        ParkingPermit permit = new ParkingPermit("P1", car, today);
        assertEquals(today.plusYears(1), permit.getExpirationDate());
    }
}