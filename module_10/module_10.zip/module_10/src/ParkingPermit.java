import java.time.LocalDate;

public class ParkingPermit {
    private final String id;
    private final Car car;
    private final LocalDate registrationDate;
    private final LocalDate expirationDate;

    public ParkingPermit(String id, Car car, LocalDate registrationDate) {
        this.id = id;
        this.car = car;
        this.registrationDate = registrationDate;
        this.expirationDate = registrationDate.plusYears(1);
    }

    public String getId() { return id; }
    public Car getCar() { return car; }
    public LocalDate getExpirationDate() { return expirationDate; }
}