import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class PermitManagerTest {

    @Test
    void testRegister() {
        PermitManager pm = new PermitManager();
        Car car = new Car("N/A", "XYZ", CarType.SUV, "C1");

        ParkingPermit permit = pm.register(car);

        assertNotNull(permit.getId());
        assertEquals(car, permit.getCar());
    }

    @Test
    void testGetPermits() {
        PermitManager pm = new PermitManager();
        Car car = new Car("N/A", "XYZ", CarType.SUV, "C1");

        ParkingPermit permit = pm.register(car);

        Map<String, ParkingPermit> permits = pm.getPermits();

        assertEquals(1, permits.size());
        assertTrue(permits.containsKey(permit.getId()));
        assertEquals(permit, permits.get(permit.getId()));
    }
}