import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TransactionManager {
    private final List<ParkingTransaction> transactions = new ArrayList<>();

    public ParkingTransaction park(Date date, ParkingPermit permit, ParkingLot lot) {

        Money fee = lot.getDailyRate(permit.getCar().getType());
        ParkingTransaction tx = new ParkingTransaction(date, permit, lot, fee);
        transactions.add(tx);
        return tx;
    }

    public Money getParkingCharges(ParkingPermit permit) {
        long totalCents = 0;
        for (ParkingTransaction tx : transactions) {
            if (tx.getPermit().equals(permit)) {
                totalCents += tx.getFeeCharged().getCents();
            }
        }
        return new Money(totalCents);
    }


    public Money getParkingCharges(String licensePlate) {
        long totalCents = 0;
        for (ParkingTransaction tx : transactions) {
            if (tx.getPermit().getCar().getLicense().equals(licensePlate)) {
                totalCents += tx.getFeeCharged().getCents();
            }
        }
        return new Money(totalCents);
    }
}