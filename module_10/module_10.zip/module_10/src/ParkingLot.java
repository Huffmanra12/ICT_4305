import java.util.Objects;

public class ParkingLot {
    private final String id;
    private final String name;
    private final Address address;
    private final Money dailyRate;

    public ParkingLot(String id, String name, Address address, Money dailyRate) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.dailyRate = dailyRate;
    }

    // Getters
    public String getId() { return id; }
    public String getName() { return name; }
    public Address getAddress() { return address; }
    public Money getDailyRate(CarType type) {
        if (type == CarType.COMPACT) {
            long discountedCents = (long) (dailyRate.getCents() * 0.8);
            return new Money(discountedCents);
        }
        return dailyRate;
    }

    @Override
    public String toString() {
        return "Lot ID: " + id + " (" + name + ") at " + address.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ParkingLot)) return false;
        ParkingLot that = (ParkingLot) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}