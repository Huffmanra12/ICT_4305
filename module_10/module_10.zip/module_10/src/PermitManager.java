import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.time.LocalDate;

public class PermitManager {

    private final Map<String, ParkingPermit> permits = new HashMap<>();

    public ParkingPermit register(Car car) {
        String id = "PRMT-" + UUID.randomUUID().toString().substring(0, 8);
        ParkingPermit permit = new ParkingPermit(id, car, LocalDate.now());
        permits.put(id, permit);
        return permit;
    }

    public ParkingPermit getPermit(String id) {
        return permits.get(id);
    }

    public Map<String, ParkingPermit> getPermits() {
        return permits;
    }
}