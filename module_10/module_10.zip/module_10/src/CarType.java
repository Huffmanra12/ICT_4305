public enum CarType {
    COMPACT,
    SUV,
    TRUCK,
    MOTORCYCLE,
    VAN
}
