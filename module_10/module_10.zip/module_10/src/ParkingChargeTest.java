import org.junit.jupiter.api.Test;

import java.time.Instant;

import static org.junit.jupiter.api.Assertions.*;

public class ParkingChargeTest {

    Money amount = new Money(1500);
    Instant incurredTime = Instant.now();

    ParkingCharge charge = new ParkingCharge("123456789", "Lot A", incurredTime, amount);

    @Test
    void testGetPermitID() {
        assertEquals("123456789", charge.getPermitID());
    }

    @Test
    void testGetLotID() {
        assertEquals("Lot A", charge.getLotID());
    }

    @Test
    void testGetIncurred() {
        assertEquals(incurredTime, charge.getIncurred());
    }

    @Test
    void testToString() {
        String result = charge.toString();

        assertTrue(result.contains("123456789"));
        assertTrue(result.contains("Lot A"));
        assertTrue(result.contains("$15.00"));
    }

    @Test
    void testEqualsAndHashCode() {
        ParkingCharge charge2 = new ParkingCharge("123456789", "Lot A", incurredTime, new Money(1500));
        assertEquals(charge, charge2);
        assertEquals(charge.hashCode(), charge2.hashCode());
    }
}