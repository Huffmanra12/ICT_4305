import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class ParkingOfficeTest {
    private ParkingOffice office;
    private Customer customer;
    private Car car;
    private ParkingLot lot;

    @BeforeEach
    void setUp() {
        Address addr = new Address("Admin St", "", "Denver", "CO", "80208");
        office = new ParkingOffice("Admin Office", addr);

        customer = new Customer("C1", "Richard", "Huffman", addr, "555-555");

        car = customer.register("ABC123", CarType.SUV);

        lot = new ParkingLot("L1", "Regis Lot", addr, new Money(1000));
    }

    @Test
    void testRegisterAndPark() {
        office.register(customer);
        ParkingPermit permit = office.register(car);
        assertNotNull(permit);

        ParkingTransaction tx = office.park(new Date().toInstant(), permit, lot);
        assertNotNull(tx);

        Money charge = office.getParkingCharges(permit);
        assertEquals(1000, charge.getCents());
    }

    @Test
    void testCustomerTotalCharges() {
        office.register(customer);

        ParkingPermit permit = office.register(car);
        office.park(new Date().toInstant(), permit, lot);
        office.park(new Date().toInstant(), permit, lot);

        Money total = office.getParkingCharges(customer);
        assertEquals(2000, total.getCents());
    }
}