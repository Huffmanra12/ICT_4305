import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ParkingLotTest {
    Address lotAddr = new Address("3333 Regis Blvd", "", "Denver", "CO", "80221");
    ParkingLot lot = new ParkingLot("Lot 1", "Main Lot", lotAddr, new Money(1000));

    @Test
    void testLotInfo() {
        assertEquals("Lot 1", lot.getId());
        assertEquals(lotAddr, lot.getAddress());
    }

    @Test
    void testRates() {
        // Standard rate
        assertEquals(1000, lot.getDailyRate(CarType.SUV).getCents());
        // 20% Discount for compact
        assertEquals(800, lot.getDailyRate(CarType.COMPACT).getCents());
    }
}