import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class AddressTest {

    Address addr = new Address("1020 S Blackhawk St", "Apt 2214", "Aurora", "CO", "80012");

    @Test
    void testGetStreetAddress1() {
        assertEquals("1020 S Blackhawk St", addr.getStreetAddress1());
    }

    @Test
    void testGetStreetAddress2() {
        assertEquals("Apt 2214", addr.getStreetAddress2());
    }

    @Test
    void testGetCity() {
        assertEquals("Aurora", addr.getCity());
    }

    @Test
    void testGetState() {
        assertEquals("CO", addr.getState());
    }

    @Test
    void testGetZipCode() {
        assertEquals("80012", addr.getZipCode());
    }

    @Test
    void testToString() {
        assertEquals("1020 S Blackhawk St, Apt 2214, Aurora, CO 80012", addr.toString());
    }
}