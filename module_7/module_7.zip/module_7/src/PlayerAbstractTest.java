import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PlayerAbstractTest {

    @Test
    void nflPlayerA_extendsAbstractCorrectly() {
        PlayerA p = new NflPlayerA("Tom Brady", 99836);

        assertEquals("Tom Brady", p.getNameA());
        assertEquals(99836, p.getStatsA());
        assertEquals("NFL", p.getSportA());
    }

    @Test
    void nbaPlayerA_extendsAbstractCorrectly() {
        PlayerA p = new NbaPlayerA("Larry Bird", 649);

        assertEquals("Larry Bird", p.getNameA());
        assertEquals(649, p.getStatsA());
        assertEquals("NBA", p.getSportA());
    }
}