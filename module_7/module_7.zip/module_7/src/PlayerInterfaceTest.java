import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PlayerInterfaceTest {

    @Test
    void nflPlayer_implementsPlayerCorrectly() {
        Player p = new NflPlayer("Tom Brady", 99836);

        assertEquals("Tom Brady", p.getName());
        assertEquals(99836, p.getStats());
        assertEquals("NFL", p.getSport());
    }

    @Test
    void nbaPlayer_implementsPlayerCorrectly() {
        Player p = new NbaPlayer("Larry Bird", 649);

        assertEquals("Larry Bird", p.getName());
        assertEquals(649, p.getStats());
        assertEquals("NBA", p.getSport());
    }
}
