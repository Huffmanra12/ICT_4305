public class NflPlayerA extends PlayerA {

    public NflPlayerA(String name, int stats) {
        super(name, stats, "NFL");
    }

    @Override
    public int getStatsA() {
        return stats;
    }

    @Override
    public String getSportA() {
        return sport;
    }
}