public abstract class PlayerA {
    protected String name;
    protected int stats;
    protected String sport;

    public PlayerA(String name, int stats, String sport) {
        this.name = name;
        this.stats = stats;
        this.sport = sport;
    }

    public String getNameA() {
        return name;
    }

    public abstract int getStatsA();
    public abstract String getSportA();
}
