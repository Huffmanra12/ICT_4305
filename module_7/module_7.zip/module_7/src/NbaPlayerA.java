public class NbaPlayerA extends PlayerA {

    public NbaPlayerA(String name, int stats) {
        super(name, stats, "NBA");
    }

    @Override
    public int getStatsA() {
        return stats;
    }

    @Override
    public String getSportA() {
        return sport;
    }
}